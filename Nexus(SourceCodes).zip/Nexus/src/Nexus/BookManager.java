/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nexus;
import java.io.*;
import java.util.ArrayList;

/**
 *
 * @author hrith
 */
public class BookManager {
    private ArrayList<Book> booklist;
    public boolean init()
    {
        try{
            FileReader fr = new FileReader("Book.csv");
            BufferedReader br = new BufferedReader(fr);
            Book book=null;
            String line=br.readLine();
            while(line!=null){
                book=new Book();
                line=br.readLine();
                if(line==null)
                    break;
                String[] f = line.split(",");
                book.setBook(f[0],f[1],f[2],f[3],f[4],f[5]);
                booklist.add(book);
            }
            br.close();
        }catch(Exception e){
            System.out.println(e);
        }
        return true;
    }
    public ArrayList<Book> getbooks(){
        return booklist;
    }
    public Book searchBook(String bookname)
    {
        BufferedReader reader=null;
        try{
            String line="";
            reader=new BufferedReader(new FileReader("Book.csv"));
            Book book=new Book();
            
            while((line=reader.readLine())!=null)
            {
                String[] f=line.split(",");
                if(f[1].equals(bookname))
                {
                    book.setBook(f[0],f[1],f[2],f[3],f[4],f[5]);
                    reader.close();
                    return book;
                }
                
            }
            
        }catch(Exception e)
        {
            e.printStackTrace();
        }finally {
         try {
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
         
        }
        
        return null;
    }
    
    public ArrayList<Book> searchBook(String dept,String year,String sub)
    {
        ArrayList<Book> books=new ArrayList<>();
        BufferedReader reader=null;
        int flag=0;
        try{
            String line="";
            reader=new BufferedReader(new FileReader("Book.csv"));
            Book book;
            
            while((line=reader.readLine())!=null)
            {
                book=new Book();
                String[] f=line.split(",");
                if(f[3].equals(dept) || f[4].equals(year) || f[5].equals(sub))
                {
                    flag=1;
                    book.setBook(f[0],f[1],f[2],f[3],f[4],f[5]);
                    books.add(book);
                }
                
            }
            reader.close();
            return books;
            
        }catch(Exception e)
        {
            e.printStackTrace();
        }finally {
         try {
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
         
        }
        if(flag==0)
        {
            return null;
        }
        return null;
    }
    
    public Boolean addBook(Book book)
    {
        boolean result = false;
            
            try {
                BufferedWriter out = new BufferedWriter( 
                   new FileWriter("Book.csv", true));
                String a=book.getUniqueCode()+","+book.getBookName()+","+book.getAuthor()+","+book.getDept()+","+book.getYear()+","+book.getSubject()+"\n";
                out.write(a);
                out.close();
                result = true;
                
            } catch (FileNotFoundException e) {
                System.out.println("File Not Found");
            } catch (IOException e) {
                System.out.println("IO Exception");              
            }
        
        
        return result;
    }
}
