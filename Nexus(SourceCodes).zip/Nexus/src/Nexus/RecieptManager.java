/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nexus;
import java.util.*;
import java.io.*;

/**
 *
 * @author hrith
 */
public class RecieptManager {

    public String generateReciept(String username,double fee)
    {
        Date obj=new Date();
                   String date=obj.toString(); 
                    try
                    {
                        String userPath = System.getProperty("user.home") + "/";
                        String path=userPath.replace("\\", "/");
                        File file=new File(path+"Receipt.txt");
                        if(file.createNewFile())
                        {
                            System.out.println("File created");
                        }
                        else{
                            System.out.println("File exists");
                        }
                        FileWriter fo=new FileWriter(file);

                    fo.write("                  Reciept\n");
                    fo.write("Invoice to:\n");
                    fo.write("Name: "+username+"\n");
                    fo.write("Date: "+date+"\n");
                    fo.write("Amount: "+fee+"\n");
                    fo.write("Librarian's Name: "+"rTk\n");
                    fo.write("******************Thank You!******************");
                    
                     fo.close();
                     return file.getPath();
                     
                    }
                    catch(Exception e)
                    {
                            System.out.println(e);
                            return "";
                    }
    }
//    public static void main(String args[])
//    {
//        RecieptManager rm=new RecieptManager();
//        if(rm.generateReciept("Hrithik", 0))
//        {
//            System.out.println("Successful");
//        }
//        else{
//            System.out.println("Unsuccessful");
//        }
//    }
    
}
