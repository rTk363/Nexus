/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nexus;

/**
 *
 * @author hrith
 */
public class User {
    private String username;
    private int userID;
    private String email;
    private String password;
    private double fee=0.0d;
    
    public void setUsername(String a)
    {
        this.username=a;
    }
    public void setUserID(int a)
    {
        this.userID=a;
    }
    public void setEmail(String a)
    {
        this.email=a;
    }
    public void setPassword(String a)
    {
        this.password=a;
    }
    public String getUsername()
    {
        return username;
    }
    public int getUserID()
    {
        return userID;
    }
    public String getEmail()
    {
        return email;
    }
    public String getPassword()
    {
        return password;
    }
    public double getFee()
    {
        return fee;
    }
    public void setFee(double fee)
    {
        this.fee=fee;
    }

}
