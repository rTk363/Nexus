/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nexus;

import java.io.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author hrith
 */
public class UserManager {
    private ArrayList<User> list;
    public boolean init(){
        list=new ArrayList<>();
        try{
            FileReader r = new FileReader("User.csv");
            BufferedReader br = new BufferedReader(r);
            User user=null;
            String line=br.readLine();
            while(line!=null){
                user=new User();
                line=br.readLine();
                if(line==null)
                    break;
                String[] f = line.split(",");
                user.setUsername(f[0]);
                    user.setUserID(Integer.parseInt(f[1]));
                    user.setEmail(f[2]);
                    user.setPassword(f[3]);
                list.add(user);
                          
            } 
            br.close();
        }catch(Exception e){
            //System.out.println(e.getMessage());
        }        
        return true;
    }
    public ArrayList<User> getList(){
        return list;
    }
    public User search(String userID)
    {
        BufferedReader reader=null;
        try{
            String line="";
            reader=new BufferedReader(new FileReader("User.csv"));
            User user=new User();
            
            while((line=reader.readLine())!=null)
            {
                String[] f=line.split(",");
                if(f[1].equals(userID))
                {
                    user.setUsername(f[0]);
                    user.setUserID(Integer.parseInt(f[1]));
                    user.setEmail(f[2]);
                    user.setPassword(f[3]);
                    reader.close();
                    return user;
                }
                
            }
            
        }catch(Exception e)
        {
            //e.printStackTrace();
        }finally {
         try {
            reader.close();
        } catch (Exception e) {
            //e.printStackTrace();
        }
         
    }
        
        return null;
}
    public Boolean checkPassword(User user,String pass){
        if(pass.equals(user.getPassword()))
        {
            return true;
        }
        return false;
    }
    public Boolean addUser(User user)
    {
        boolean result = false;
            
            try {
                BufferedWriter out = new BufferedWriter( 
                   new FileWriter("User.csv", true));
                String a=user.getUsername()+","+user.getUserID()+","+user.getEmail()+","+user.getPassword()+"\n";
                out.write(a);
                out.close();
                result = true;
                
            } catch (FileNotFoundException e) {
                System.out.println("File Not Found");
            } catch (IOException e) {
                    System.out.println("IO Exception");              
            }
        
        
        return result;
    }
    public ArrayList<User> searchUsers()
    {
        ArrayList<User> users=new ArrayList<>();
        BufferedReader reader=null;
        try{
            String line="";
            reader=new BufferedReader(new FileReader("User.csv"));
            
            
            while((line=reader.readLine())!=null)
            {
                User user=new User();
                String[] f=line.split(",");
                    user.setUsername(f[0]);
                    user.setUserID(Integer.parseInt(f[1]));
                    user.setEmail(f[2]);
                    user.setPassword(f[3]);
                    users.add(user);
                    
                
            }
            reader.close();
            return users;
            
        }catch(Exception e)
        {
            //e.printStackTrace();
        }finally {
         try {

        } catch (Exception e) {
            //e.printStackTrace();
        }
         
    }
        
        return null;
        
    }
}
