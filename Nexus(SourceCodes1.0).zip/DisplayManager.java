/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nexus;

import javax.swing.JOptionPane;

/**
 *
 * @author hrith
 */
public class DisplayManager {
    private User user;
    private SignInPage sip;
    private Register r;
    private DashBoard db;
    private DashBoardAdmin dba;
    static private UserManager um;
    static private BookManager bm;
    static private RecieptManager rm;
    static private FeedBackManager fm;
    DisplayManager()
    {
        um=new UserManager();
        bm=new BookManager();
        rm=new RecieptManager();
        fm=new FeedBackManager();
        um.init();
        bm.init();
    }
    public void setUser(User user)
    {
        this.user= user;
    }
    public User getUser()
    {
        return this.user;
    }
    public void displaySignInPage(){

        sip.setVisible(true);
    }
    public void displaySignUp(){
        r.setVisible(true);
    }
    public void displayDashBoard(){
        db.setUser(user);
        db.setVisible(true);
    }
    public void displayDashBoardAdmin()
    {
        dba.setUser(user);
        dba.setVisible(true);
    }
    public void logout(){
        int a=JOptionPane.showConfirmDialog(null,"Are you sure you want to Log Out?");
        if(a==0)
        {
            sip.setVisible(true);
            db.dispose();
            dba.dispose();
        }
    }
    public static void main(String args[])
    {
        DisplayManager dm=new DisplayManager();
        dm.sip=new SignInPage(dm);
        dm.displaySignInPage();
        dm.r=new Register(dm);
        dm.db=new DashBoard(dm,bm,fm,rm,um);
        dm.dba=new DashBoardAdmin(dm,dm.um);

    }
    
}
