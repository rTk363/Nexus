/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nexus;

/**
 *
 * @author hrith
 */
public class Book {
    private String uniqueCode;
    private String book_name;
    private String author;
    private String dept;
    private String year;
    private String subject;
    
    public void setBook(String a,String b, String c, String d, String e, String f)
    {
        this.uniqueCode=a;
        this.book_name=b;
        this.author=c;
        this.dept=d;
        this.year=e;
        this.subject=f;
        
    }
    public String getUniqueCode()
    {
        return uniqueCode;
    }
    public String getBookName()
    {
        return book_name;
    }
    public String getAuthor()
    {
        return author;
    }
    public String getDept()
    {
        return dept;
    }
    public String getYear()
    {
        return year;
    }
    public String getSubject()
    {
        return subject;
    }
    
}
