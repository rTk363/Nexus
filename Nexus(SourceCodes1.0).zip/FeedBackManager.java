/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nexus;
import java.io.*;


/**
 *
 * @author hrith
 */
public class FeedBackManager {
    public Boolean addFeedBack(String visit,String visit_txt,String find,String find_txt,String info,String like,String comment)
    {
        boolean result = false;
            
            try {
                BufferedWriter out = new BufferedWriter( 
                   new FileWriter("Feedback.csv", true));
                String a=visit+","+visit_txt+","+find+","+find_txt+","+info+","+like+","+comment+"\n";
                out.write(a);
                out.close();
                result = true;
                
            } catch (FileNotFoundException e) {
                System.out.println("File Not Found");
            } catch (IOException e) {
                System.out.println("IO Exception");              
            }
        
        
        return result;
    }
    
}
